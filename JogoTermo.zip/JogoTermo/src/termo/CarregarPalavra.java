package termo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

public class CarregarPalavra {

    public List<String> carregarPalavra(String filename) {
        List<String> palavrasCincoLetras = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String palavraNormalizada = normalizar(linha.trim());
                if (palavraNormalizada.length() == 5) {
                    palavrasCincoLetras.add(linha.trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return palavrasCincoLetras;
    }

    private String normalizar(String entrada) {
        return Normalizer.normalize(entrada, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase();
    }
}
