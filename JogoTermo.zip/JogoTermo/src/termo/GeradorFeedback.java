package termo;

public class GeradorFeedback {

    public static String gerarFeedback(String alvo, String palpite) {
        StringBuilder feedback = new StringBuilder();

        for (int i = 0; i < alvo.length(); i++) {
            char caractereAlvo = alvo.charAt(i);
            char caracterePalpite = palpite.charAt(i);

            if (caractereAlvo == caracterePalpite) {
                feedback.append("\u001B[32m"); // Verde
            } else if (alvo.contains(String.valueOf(caracterePalpite))) {
                feedback.append("\u001B[33m"); // Amarelo
            } else {
                feedback.append("\u001B[37m"); // Cinza
            }

            feedback.append(caracterePalpite).append(" \u001B[0m"); // Resetar cor
        }

        return feedback.toString();
    }
}
