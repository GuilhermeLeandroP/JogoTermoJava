package termo;

import termo.GeradorFeedback;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Jogo {

    private static final int MAX_TENTATIVAS = 5;

    private List<String> palavrasCincoLetras;
    private String palavraAlvo;

    public Jogo() {
        CarregarPalavra carregarPalavra = new CarregarPalavra();
        this.palavrasCincoLetras = carregarPalavra.carregarPalavra("palavras.txt");
        this.palavraAlvo = obterPalavraAleatoria();
    }

    public void iniciarJogo() {
        System.out.println("Bem-vindo ao Wordle!");
        System.out.println("Tente adivinhar a palavra de cinco letras.");
        System.out.println("As letras certas na posição correta ficarão em verde,");
        System.out.println("as letras corretas em posição diferente ficarão em amarelo.");
        System.out.println("Letras que não fazem parte da palavra ficarão em cinza.");

        for (int tentativa = 1; tentativa <= MAX_TENTATIVAS; tentativa++) {
            System.out.println("\nTentativa " + tentativa + "/" + MAX_TENTATIVAS);
            String palpite = obterPalpite();
            String feedback = GeradorFeedback.gerarFeedback(palavraAlvo, palpite);

            System.out.println(feedback);

            if (palpite.equals(palavraAlvo)) {
                System.out.println("Parabéns! Você acertou a palavra.");
                return;
            }
        }

        System.out.println("\nVocê atingiu o número máximo de tentativas. A palavra correta era: " + palavraAlvo);
    }

    private String obterPalavraAleatoria() {
        Random rand = new Random();
        return palavrasCincoLetras.get(rand.nextInt(palavrasCincoLetras.size()));
    }

    private String obterPalpite() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite seu palpite: ");
        return scanner.next().toLowerCase();
    }
}
